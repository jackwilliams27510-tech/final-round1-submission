import pandas as pd

# Load the best parameter sweep results from the correct folder
df = pd.read_csv('final_round1_submission/param_sweep_batch_best.csv')

total_pnl = df['pnl'].sum()

print(f"Total P&L from param_sweep_batch_best.csv: {total_pnl:.1f}")
