import pandas as pd
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import pairs_trading_engine as engine

# Load best parameter sweep results
best = pd.read_csv('final_round1_submission/param_sweep_batch_best.csv')

df = engine.load_and_prepare()

all_trades = []
for _, row in best.iterrows():
    prodA, prodB = row['pair'].split('|')
    engine.ENTRY_Z = row['entry_z']
    engine.EXIT_Z = row['exit_z']
    engine.HEDGE_WINDOW = int(row['hedge_window'])
    res = engine.backtest_pair(df, prodA, prodB)
    if res and 'trades' in res:
        for t in res['trades']:
            # t: (timestamp, product, side, units, price)
            all_trades.append({
                'pair': row['pair'],
                'timestamp': t[0],
                'product': t[1],
                'side': t[2],
                'units': t[3],
                'price': t[4]
            })

trades_df = pd.DataFrame(all_trades)
outfile = Path('final_round1_submission/trade_log.csv')
trades_df.to_csv(outfile, index=False)
print(f"Trade log saved to {outfile}")
