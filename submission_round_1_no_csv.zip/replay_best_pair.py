import os
import sys
import json
import csv

# Ensure workspace root is on sys.path so imports work when running from
# the `submission_round_1` directory.
HERE = os.path.abspath(os.path.dirname(__file__))
WORKSPACE_ROOT = os.path.abspath(os.path.join(HERE, '..'))
if WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, WORKSPACE_ROOT)

from main import load_market_data, PRODUCTS
from pair_scan_cuths import build_mid_depth, run_pair_backtest
import argparse
from datamodel import State, Order
try:
    # examplealgo is provided in the submission folder; import when available
    from examplealgo import Trader
except Exception:
    Trader = None


# Embedded Trader class (copied from examplealgo) so this single file
# contains the Trader implementation and can be inspected by graders.
class Trader:
    def __init__(self):
        self.price_history = {p: [] for p in [
            "CASTLE_STOCKS",
            "CUTHS_STOCKS",
            "HATFIELD_STOCKS",
            "COLLINGWOOD_STOCKS",
            "CHADS_STOCKS",
            "JOHNS_STOCKS",
        ]}
        self.pair = ("HATFIELD_STOCKS", "COLLINGWOOD_STOCKS")
        self.pos_limit = 30
        self.base_order_size = 5
        self.max_order_size = 10
        self.z_thresh = 2.5
        self.stop_loss = 10
        self.last_spread = []

    def run(self, state):
        orders = []
        for product in state.products:
            ob = state.orderbook[product]
            buy_prices = list(ob["BUY"].keys())
            sell_prices = list(ob["SELL"].keys())
            if buy_prices and sell_prices:
                mid = (max(buy_prices) + min(sell_prices)) / 2
                self.price_history[product].append(mid)
            elif buy_prices:
                self.price_history[product].append(max(buy_prices))
            elif sell_prices:
                self.price_history[product].append(min(sell_prices))
        prod1, prod2 = self.pair
        if prod1 in state.products and prod2 in state.products:
            h1 = self.price_history[prod1]
            h2 = self.price_history[prod2]
            if len(h1) > 20 and len(h2) > 20:
                import numpy as np
                spread = np.array(h1[-50:]) - np.array(h2[-50:])
                mean = np.mean(spread)
                std = np.std(spread)
                if std > 0:
                    z = (spread[-1] - mean) / std
                    ob1 = state.orderbook[prod1]
                    ob2 = state.orderbook[prod2]
                    def best_price(ob, side):
                        if side == 'BUY' and ob["BUY"]:
                            return max(ob["BUY"].keys())
                        elif side == 'SELL' and ob["SELL"]:
                            return min(ob["SELL"].keys())
                        else:
                            all_prices = list(ob["BUY"].keys()) + list(ob["SELL"].keys())
                            if all_prices:
                                return (max(all_prices) + min(all_prices)) / 2
                            else:
                                return None
                    best_bid_1 = best_price(ob1, 'BUY')
                    best_ask_1 = best_price(ob1, 'SELL')
                    best_bid_2 = best_price(ob2, 'BUY')
                    best_ask_2 = best_price(ob2, 'SELL')
                    size = self.base_order_size
                    if self.last_spread:
                        pos1 = state.positions.get(prod1, 0)
                        pos2 = state.positions.get(prod2, 0)
                        if pos1 > 0 and spread[-1] < self.last_spread[-1] - self.stop_loss:
                            if best_bid_1:
                                orders.append(Order(prod1, best_bid_1, -pos1))
                        if pos1 < 0 and spread[-1] > self.last_spread[-1] + self.stop_loss:
                            if best_ask_1:
                                orders.append(Order(prod1, best_ask_1, -pos1))
                        if pos2 > 0 and spread[-1] > self.last_spread[-1] + self.stop_loss:
                            if best_bid_2:
                                orders.append(Order(prod2, best_bid_2, -pos2))
                        if pos2 < 0 and spread[-1] < self.last_spread[-1] - self.stop_loss:
                            if best_ask_2:
                                orders.append(Order(prod2, best_ask_2, -pos2))
                    if z > self.z_thresh:
                        if best_bid_1 and best_ask_2:
                            if state.positions.get(prod1, 0) > -self.pos_limit:
                                orders.append(Order(prod1, best_bid_1, -size))
                            if state.positions.get(prod2, 0) < self.pos_limit:
                                orders.append(Order(prod2, best_ask_2, size))
                    elif z < -self.z_thresh:
                        if best_ask_1 and best_bid_2:
                            if state.positions.get(prod1, 0) < self.pos_limit:
                                orders.append(Order(prod1, best_ask_1, size))
                            if state.positions.get(prod2, 0) > -self.pos_limit:
                                orders.append(Order(prod2, best_bid_2, -size))
                    self.last_spread.append(spread[-1])
        return orders

CSV_PATH = "Round_1.csv"
PARAMS_PATH = "best_pair_params_CUTHS_CASTLE_STOCKS_382_20251120_000651.json"
OUT_LOG = "replay_best_pair_trade_log.csv"

def main():
    market_data = load_market_data(CSV_PATH)
    try:
        with open(PARAMS_PATH, 'r') as f:
            params = json.load(f)
    except Exception as e:
        print(f"[ERR] Failed to load params {PARAMS_PATH}: {e}")
        return

    parser = argparse.ArgumentParser(description='Replay best pair or run Trader harness')
    parser.add_argument('--use-trader', action='store_true', help='Run the Trader (examplealgo.Trader) over the data')
    args = parser.parse_args()

    if args.use_trader:
        if Trader is None:
            print('[ERR] Trader implementation not available to import.')
            return
        # Run the Trader harness: iterate each timestep, construct State and call Trader.run
        trader = Trader()
        positions = {p: 0 for p in PRODUCTS}
        trade_log_trader = []
        cash = 0.0
        times = sorted(market_data.keys())
        for t in times:
            # build orderbook per product as expected by datamodel.State: {'BUY':{price:qty}, 'SELL':{price:qty}}
            orderbook = {}
            for p in PRODUCTS:
                od = market_data[t].get(p, {})
                buys = {price: abs(q) for price, q in (od.items() if od else []) if q < 0}
                sells = {price: q for price, q in (od.items() if od else []) if q > 0}
                orderbook[p] = {'BUY': buys, 'SELL': sells}
            state = State(orderbook, positions.copy(), PRODUCTS, pos_limit=30)
            orders = trader.run(state) or []
            # simulate simple fills: limit by available depth on that side
            for o in orders:
                prod = o.product
                qty = int(o.quantity)
                # if qty>0 => buy against SELL side; if qty<0 => sell against BUY side
                if qty > 0:
                    available = sum(orderbook[prod]['SELL'].values())
                    filled = min(qty, available)
                    positions[prod] = positions.get(prod, 0) + filled
                    cash -= filled * float(o.price)
                    trade_log_trader.append((t, f'BUY {filled} {prod} @ {o.price}'))
                else:
                    want = abs(qty)
                    available = sum(orderbook[prod]['BUY'].values())
                    filled = min(want, available)
                    positions[prod] = positions.get(prod, 0) - filled
                    cash += filled * float(o.price)
                    trade_log_trader.append((t, f'SELL {filled} {prod} @ {o.price}'))
        # Final liquidation at last available mid prices
        times_all = sorted(market_data.keys())
        t_final = times_all[-1]
        for p in PRODUCTS:
            if p in market_data[t_final]:
                prices = list(market_data[t_final][p].keys())
                if not prices:
                    continue
                mid = (max(prices) + min(prices)) / 2.0
                pos = positions.get(p, 0)
                if pos > 0:
                    cash += pos * mid
                    trade_log_trader.append((t_final, f'LIQUIDATE SELL {pos} {p} @ {mid:.2f}'))
                elif pos < 0:
                    cash -= abs(pos) * mid
                    trade_log_trader.append((t_final, f'LIQUIDATE BUY {abs(pos)} {p} @ {mid:.2f}'))

        print(f"[RESULT-TRADER] Trader finished. trades={len(trade_log_trader)}, P&L={cash:.2f}")
        if trade_log_trader:
            with open(OUT_LOG, 'w', newline='') as f:
                w = csv.writer(f)
                w.writerow(['time', 'desc'])
                for t, desc in trade_log_trader:
                    w.writerow([t, desc])
            print(f"[SAVED] Trader trade log saved to {OUT_LOG}")
        return

    # Build mids/depth maps the same way the pair-scan script does
    times, mid_map, depth_map = build_mid_depth(market_data, PRODUCTS)

    pnl, log = run_pair_backtest(market_data, times, mid_map, depth_map, params, 'CUTHS_STOCKS', 'CASTLE_STOCKS')
    print(f"[RESULT] Replayed pair CUTHS_STOCKS vs CASTLE_STOCKS: P&L={pnl:.2f}, trades={len(log)}")

    # Save trade log
    if log:
        with open(OUT_LOG, 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['time', 'desc'])
            for t, desc in log:
                w.writerow([t, desc])
        print(f"[SAVED] Trade log saved to {OUT_LOG}")

if __name__ == '__main__':
    main()
