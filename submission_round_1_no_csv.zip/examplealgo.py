from datamodel import *
import numpy as np

class Trader:
    def __init__(self):
        # Store price history for each product for z-score calculation
        self.price_history = {p: [] for p in [
            "CASTLE_STOCKS",
            "CUTHS_STOCKS",
            "HATFIELD_STOCKS",
            "COLLINGWOOD_STOCKS",
            "CHADS_STOCKS",
            "JOHNS_STOCKS",
        ]}
        # Focus on best pair for pair trading
        self.pair = ("HATFIELD_STOCKS", "COLLINGWOOD_STOCKS")
        self.pos_limit = 30
        self.base_order_size = 5
        self.max_order_size = 10
        self.z_thresh = 2.5  # Default to high threshold; overwritten by parameter sweep
        self.stop_loss = 10  # Stop-loss threshold (in price units)
        self.last_spread = []

    def run(self, state):
        orders = []
        # Update price history with current mid prices
        for product in state.products:
            ob = state.orderbook[product]
            buy_prices = list(ob["BUY"].keys())
            sell_prices = list(ob["SELL"].keys())
            if buy_prices and sell_prices:
                mid = (max(buy_prices) + min(sell_prices)) / 2
                self.price_history[product].append(mid)
            elif buy_prices:
                self.price_history[product].append(max(buy_prices))
            elif sell_prices:
                self.price_history[product].append(min(sell_prices))
        # Debug: print price history lengths
        print(f"[DEBUG] Price history lens: {[len(self.price_history[p]) for p in state.products]}")
        # Focus on the most profitable pair
        prod1, prod2 = self.pair
        if prod1 in state.products and prod2 in state.products:
            h1 = self.price_history[prod1]
            h2 = self.price_history[prod2]
            if len(h1) > 20 and len(h2) > 20:
                spread = np.array(h1[-50:]) - np.array(h2[-50:])  # use last 50 points
                mean = np.mean(spread)
                std = np.std(spread)
                if std > 0:
                    z = (spread[-1] - mean) / std
                    print(f"[DEBUG] {prod1}/{prod2} z-score: {z:.2f} (mean={mean:.2f}, std={std:.2f})")
                    ob1 = state.orderbook[prod1]
                    ob2 = state.orderbook[prod2]
                    # Get best bid/ask/mid for each product
                    def best_price(ob, side):
                        if side == 'BUY' and ob["BUY"]:
                            return max(ob["BUY"].keys())
                        elif side == 'SELL' and ob["SELL"]:
                            return min(ob["SELL"].keys())
                        else:
                            # Use mid if one side is missing
                            all_prices = list(ob["BUY"].keys()) + list(ob["SELL"].keys())
                            if all_prices:
                                return (max(all_prices) + min(all_prices)) / 2
                            else:
                                return None
                    best_bid_1 = best_price(ob1, 'BUY')
                    best_ask_1 = best_price(ob1, 'SELL')
                    best_bid_2 = best_price(ob2, 'BUY')
                    best_ask_2 = best_price(ob2, 'SELL')
                    size = self.base_order_size
                    # Stop-loss: if spread moves against us by more than stop_loss, close position
                    if self.last_spread:
                        pos1 = state.positions.get(prod1, 0)
                        pos2 = state.positions.get(prod2, 0)
                        if pos1 > 0 and spread[-1] < self.last_spread[-1] - self.stop_loss:
                            if best_bid_1:
                                orders.append(Order(prod1, best_bid_1, -pos1))
                                print(f"[DEBUG] Stop-loss triggered for {prod1} long position.")
                        if pos1 < 0 and spread[-1] > self.last_spread[-1] + self.stop_loss:
                            if best_ask_1:
                                orders.append(Order(prod1, best_ask_1, -pos1))
                                print(f"[DEBUG] Stop-loss triggered for {prod1} short position.")
                        if pos2 > 0 and spread[-1] > self.last_spread[-1] + self.stop_loss:
                            if best_bid_2:
                                orders.append(Order(prod2, best_bid_2, -pos2))
                                print(f"[DEBUG] Stop-loss triggered for {prod2} long position.")
                        if pos2 < 0 and spread[-1] < self.last_spread[-1] - self.stop_loss:
                            if best_ask_2:
                                orders.append(Order(prod2, best_ask_2, -pos2))
                                print(f"[DEBUG] Stop-loss triggered for {prod2} short position.")
                    # Only trade on very strong signals (stricter)
                    if z > self.z_thresh:
                        print(f"[DEBUG] Entered z > z_thresh block: z={z:.2f}, thresh={self.z_thresh}")
                        print(f"[DEBUG] best_bid_1: {best_bid_1}, best_ask_2: {best_ask_2}")
                        # Strong positive z-score: short prod1, long prod2
                        if best_bid_1 and best_ask_2:
                            if state.positions.get(prod1, 0) > -self.pos_limit:
                                orders.append(Order(prod1, best_bid_1, -size))
                                print(f"[DEBUG] Signal: Short {prod1} at {best_bid_1}, Long {prod2} at {best_ask_2}")
                            if state.positions.get(prod2, 0) < self.pos_limit:
                                orders.append(Order(prod2, best_ask_2, size))
                                print(f"[DEBUG] Signal: Long {prod2} at {best_ask_2}")
                        else:
                            print(f"[DEBUG] Skipping order: best_bid_1 or best_ask_2 missing.")
                    elif z < -self.z_thresh:
                        print(f"[DEBUG] Entered z < -z_thresh block: z={z:.2f}, thresh={self.z_thresh}")
                        print(f"[DEBUG] best_ask_1: {best_ask_1}, best_bid_2: {best_bid_2}")
                        # Strong negative z-score: long prod1, short prod2
                        if best_ask_1 and best_bid_2:
                            if state.positions.get(prod1, 0) < self.pos_limit:
                                orders.append(Order(prod1, best_ask_1, size))
                                print(f"[DEBUG] Signal: Long {prod1} at {best_ask_1}, Short {prod2} at {best_bid_2}")
                            if state.positions.get(prod2, 0) > -self.pos_limit:
                                orders.append(Order(prod2, best_bid_2, -size))
                                print(f"[DEBUG] Signal: Short {prod2} at {best_bid_2}")
                        else:
                            print(f"[DEBUG] Skipping order: best_ask_1 or best_bid_2 missing.")
                    # If signal is not strong, do nothing (no trade)
                self.last_spread.append(spread[-1])
        return orders
